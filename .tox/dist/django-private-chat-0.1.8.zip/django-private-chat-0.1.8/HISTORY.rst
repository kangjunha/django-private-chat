.. :changelog:

History

0.1.7 (2018-03-23)
++++++++++++++++++

* Fixed time in Message model to be timezone-aware

0.1.7 (2018-03-20)
++++++++++++++++++

* Additions for django 2.0

0.1.6 (2017-04-11)
++++++++++++++++++

* Fixed bugs with static files and added comment about extra_js block to readme

0.1.5 (2017-03-11)
++++++++++++++++++

* Added flashing other user button when he sent you a message and you're in another dialog


0.1.4 (2017-02-12)
++++++++++++++++++

* Added support for django 1.8,1.9

0.1.3 (2017-02-11)
++++++++++++++++++

* Removed uvloop from requirements


0.1.2 (2017-02-11)
++++++++++++++++++

* Fixed i18n not loaded in dialogs template bug

0.1.1 (2017-02-10)
++++++++++++++++++

* Added migrations.

0.1.0 (2017-02-10)
++++++++++++++++++

* First release on PyPI.
