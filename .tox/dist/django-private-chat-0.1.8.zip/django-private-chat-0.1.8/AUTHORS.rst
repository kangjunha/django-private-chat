=======
Credits
=======

Development Lead
----------------

* delneg <tech@bearle.ru>
* guitarmustafa <oleg5432101@rambler.ru>

Contributors
------------

None yet. Why not be the first?
